function dis(val) {
  document.getElementById("result").value += val;
}
function solve() {
  const x = document.getElementById("result").value;
  const y = eval(x);
  document.getElementById("result").value = y ;
}
function cls() {
  document.getElementById("result").value = "";
}
function Back() {
  var Back = document.getElementById("result").value;
  Back = Back.substr(0 ,Back.length -1);
  document.getElementById("result").value = Back;
}
function square() {
  document.getElementById("result").value=Math.pow(document.getElementById("result").value,2);
}